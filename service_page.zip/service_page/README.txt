To enable this page, just extract services.md and put it in the home directory of the project while discarding other files if any.

Moreover, add https://taharostami.github.io/services/ to the end of sitemap file exist in the home directory of the project.